#Requires AutoHotkey v2.0
#SingleInstance Force
CoordMode "Pixel", "Screen"
CoordMode "Mouse", "Screen"

running := false
shakeTemplate := A_ScriptDir "\shake.png"

; F8 = аварийная остановка
F8::StopMacro()

; F7 = включить/выключить
F7::ToggleMacro()

; GUI
myGui := Gui("+AlwaysOnTop", "Fisch Macro")
myGui.BackColor := "111318"
myGui.SetFont("s16 Bold", "Segoe UI")
myGui.AddText("Center cFFFFFF w360", "FISCH MACRO")
myGui.SetFont("s10", "Segoe UI")
myGui.AddText("Center cA0A6B0 w360", "Auto Shake + Auto Cast")
status := myGui.AddText("Center cFF6B6B w360 y+18", "● ВЫКЛ")
btn := myGui.AddButton("w220 h45 x80 y+12", "▶ ВКЛЮЧИТЬ")
btn.OnEvent("Click", ToggleMacro)
myGui.AddText("Center c8B929E w360 y+15", "F7 — ВКЛ/ВЫКЛ`nF8 — аварийная остановка")
myGui.OnEvent("Close", (*) => ExitApp())
myGui.Show("w380 h250")

ToggleMacro(*) {
    global running, status, btn
    if running {
        StopMacro()
    } else {
        if !FileExist(A_ScriptDir "\shake.png") {
            MsgBox "Положи файл shake.png рядом с этим .ahk файлом.`n`nЭто маленький скриншот кнопки Shake из Fisch."
            return
        }
        running := true
        status.Text := "● ВКЛ"
        status.Opt("c52E68B")
        btn.Text := "■ ВЫКЛЮЧИТЬ"
        SetTimer FishCycle, 20
    }
}

StopMacro(*) {
    global running, status, btn
    running := false
    SetTimer FishCycle, 0
    Click "Up"
    status.Text := "○ ВЫКЛ"
    status.Opt("cFF6B6B")
    btn.Text := "▶ ВКЛЮЧИТЬ"
}

FishCycle() {
    global running, shakeTemplate

    ; Один цикл: заброс -> ожидание -> поиск Shake -> ловля -> новый заброс.
    SetTimer FishCycle, 0

    if !running
        return

    ; Заброс.
    Click "Down"
    Sleep 850
    Click "Up"

    ; Даем игре показать интерфейс.
    Sleep 900

    ; Ищем Shake в разных местах экрана.
    ; Если кнопка перемещается, ImageSearch выполняется снова после каждого клика.
    shakeDeadline := A_TickCount + 18000

    while running && A_TickCount < shakeDeadline {
        pos := FindShake()
        if pos {
            Click pos.x, pos.y
            Sleep 70
            continue
        }

        ; Если Shake закончился, ждем появления/окончания мини-игры.
        Sleep 40
    }

    ; В этой версии управление самой полосой ловли выполняется
    ; короткими визуальными импульсами. После исчезновения UI делаем
    ; новый заброс.
    reelDeadline := A_TickCount + 45000

    while running && A_TickCount < reelDeadline {
        ; Здесь используется визуальная проверка центральной части экрана.
        ; Если интерфейс ловли пропал, считаем цикл завершенным.
        if !FishingUIVisible() {
            break
        }

        ; Частые короткие импульсы мыши помогают удерживать управление
        ; вместо длинного фиксированного зажатия.
        Click "Down"
        Sleep 45
        Click "Up"
        Sleep 45
    }

    Click "Up"

    if running {
        Sleep 800
        SetTimer FishCycle, -1
    }
}

FindShake() {
    global shakeTemplate

    ; Поиск по всему экрану. Координаты НЕ фиксированы.
    ; Variation 35 позволяет пережить небольшие изменения яркости/масштаба.
    try {
        if ImageSearch(&x, &y, 0, 0, A_ScreenWidth, A_ScreenHeight,
                       "*" 35 " " shakeTemplate) {
            ; Клик в центр найденного шаблона.
            return {x:x + 20, y:y + 20}
        }
    } catch {
        return false
    }
    return false
}

FishingUIVisible() {
    ; Проверяем нижнюю центральную область на наличие яркой UI-полосы.
    ; Это не координата управления: область только ограничивает поиск.
    try {
        PixelSearch &x, &y, A_ScreenWidth*0.20, A_ScreenHeight*0.55,
                     A_ScreenWidth*0.80, A_ScreenHeight*0.90,
                     0xFFFFFF, 35
        return true
    } catch {
        return false
    }
}
